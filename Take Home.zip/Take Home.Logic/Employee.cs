﻿using System;

namespace TakeHome.Logic
{
    public class Employee
    {

    }
}
